package com.luffycity.devops

/**
 * @author: YongxinLi
 * @mail: inspur_lyx@hotmail.com
 * @Date: 2020-04-13
 */

import groovy.time.TimeCategory
import org.yaml.snakeyaml.Yaml
import groovy.json.JsonSlurperClassic

/**
 *
 * @param resourcePath: resource file path, dir or file
 * @param controllerFilePath: controller file path, such as deployment
 * @param watch: weather watch resource creation processing
 * @param timeoutMinutes
 * @param sleepTime
 * @param kind
 * @return
 */
def deploy(String resourcePath="deploy") {
    this.resourcePath = resourcePath
    if (!resourcePath) {
        error "resourcePath param is empty"
    }
    this.util = new Utils()
    return this
}


def start() {
    try {
        this.tplHandler()
        sh "kubectl apply -f ${this.resourcePath}"
        this.util.updateBuildMessage(env.BUILD_TASKS, "Service Deploy OK...  √")
    } catch (Exception exc) {
        updateGitlabCommitStatus(name: 'deploy', state: 'failed')
        this.util.updateBuildMessage(env.BUILD_TASKS, "Service Deploy Failed...  ×")
        echo "failed to deploy,exception: ${exc}."
        throw exc
    }
    return this
}


def tplHandler() {
    String namespace = ""
    // set default branch
    if(!env.DEV_BRANCH){
        env.DEV_BRANCH = "develop"
    }
    if(!env.QA_BRANCH){
        env.QA_BRANCH = "master"
    }
    if(env.BRANCH_NAME ==~ env.DEV_BRANCH){
        namespace = "demo"
    }else if(env.BRANCH_NAME ==~ env.QA_BRANCH){
        namespace = "qa"
    }else{
        throw new Exception("branch check not pass...")
    }
    def targetPath = "${this.resourcePath}/*"
    //replace IMAGE_REPO
    sh "sed -i 's#{{IMAGE_URL}}#${env.FULL_IMAGE_ADDRESS}#g' ${targetPath}"

    
    //namespace replace
     sh "sed -i 's#{{NAMESPACE}}#${namespace}#g' ${targetPath}"
    
    // other tpls replace
    def tpls = [
        "NODE_LABEL_KEY",
        "NODE_LABEL_VAL",
        "INGRESS_MYBLOG"
    ]
    def configMapData = this.getResource(namespace, "myblog", "configmap")["data"]
   
    for (key in tpls){
        def val = configMapData[key]
        echo "key is ${key}, val is ${val}"
        sh "sed -i 's#{{${key}}}#${val}#g' ${targetPath}"
    }
}

def getResource(String namespace = "default", String name, String kind="deployment") {
    sh "kubectl get ${kind} -n ${namespace} ${name} -o json > ${namespace}-${name}-yaml.yml"
    def jsonStr = readFile "${namespace}-${name}-yaml.yml"
    def jsonSlurper = new JsonSlurperClassic()
    def jsonObj = jsonSlurper.parseText(jsonStr)
    return jsonObj
}

